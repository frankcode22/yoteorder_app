const express = require("express");

const router=express.Router();

const {Services,Users}=require("../models");

const { validateToken } = require("../middlewares/AuthMiddleware");


router.post("/",async(req,res)=>{
    // const staff=req.body; 
const {service_name,service_type,description,service_cost,BusinessId}=req.body;

Services.create({
    service_name:service_name,
    service_type:service_type,
    description:description,
    service_cost:service_cost,
    BusinessId:BusinessId,
   
  });
  res.json("Service created Successfully");

});



router.get("/getbyId/:sId", async (req, res) => {
  const id = req.params.sId;
  const service_ = await Services.findByPk(id);
  res.json(service_);
});


router.put("/update_service/:sId", async (req, res) => {
 
  const service_name = req.body.service_name;
  const service_type = req.body.service_type;
  const description=req.body.description;
  const service_cost=req.body.service_cost;
 

  
 
  const service_ = await Services.update({service_name,service_type,description,service_cost},{ where: { id: req.params.sId}});

  res.json(service_);
  console.log(service_);
});




module.exports=router;


