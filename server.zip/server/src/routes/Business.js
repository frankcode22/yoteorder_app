const express = require("express");

const router=express.Router();

const {Business,Users,Services,Staffs,Products,Customers}=require("../models");

const { validateToken } = require("../middlewares/AuthMiddleware");

router.get("/",async(req,res)=>{
   const business_list= await Business.findAll();

  //  res.json({listOfPosts:listOfPosts,likedPosts:likedPosts});
   res.json(business_list);
});

router.get("/byId/:id", async (req, res) => {
    const id = req.params.id;
    const business = await Business.findByPk(id);
    res.json(business);
  });

  router.post("/bussinfor",async(req,res)=>{


    const {business_name,business_type,industry,location,contacts,address_line_1,latitude,longitude,city,state,country,status,UserId}=req.body;


    try {
       
  const buss_infor= await  Business.create({
    business_name:business_name,
    business_type:business_type,
    industry:industry,
    location:location,
    contacts:contacts,

    address_line_1:address_line_1,
    latitude:latitude,
    longitude:longitude,
    city:city,
    state:state,
    country:country,

    status:status,
    UserId:UserId,
   
  });
  res.json(buss_infor);

  console.log(buss_infor);


    }
 catch (err) {
      console.error(err.message)
    }



});



router.put("/updateBuss", async (req, res) => {
  const id = req.body.businessId;
  const city = req.body.city;
  const state = req.body.city;
  const latitude=req.body.latitude;
  const longitude=req.body.longitude;


  const buss = await Business.update({city,latitude,longitude,state},{ where: { id: id }});

  res.json(buss);
  console.log(buss);

  console.log('The business ID is '+id);
});




router.get("/mybusiness_services", validateToken, async (req, res) => {
 
  const my_buss = await Business.findOne({ where: { UserId: req.user.id },include: [Users,Services]});


   res.json(my_buss);
  console.log(my_buss);


 // const servicesList= await Services.findAll({ where: { BusinessId: my_buss.BusinessId } });
 
  //console.log(servicesList);
});


router.get("/buss_services/:id", validateToken, async (req, res) => {

  const id = req.params.id;
 
  const my_buss_services = await Services.findAll({ where: { BusinessId: id },include: [Business]});


  res.json(my_buss_services);
  console.log(my_buss_services);

 // const servicesList= await Services.findAll({ where: { BusinessId: my_buss.BusinessId } });
 
  //console.log(servicesList);
});


router.get("/buss_details/:id", async (req, res) => {

  const id = req.params.id;
 
  const my_buss_services = await Business.findOne({ where: { id: id },include: [Services]});


  res.json(my_buss_services);
  console.log(my_buss_services);

 // const servicesList= await Services.findAll({ where: { BusinessId: my_buss.BusinessId } });
 
  //console.log(servicesList);
});


router.get("/bestRated", async (req, res) => {

 
 
  const best_rated = await Business.findAll({include: [Users,Customers,Products,Services]});


  res.json(best_rated);
  console.log(best_rated);

 // const servicesList= await Services.findAll({ where: { BusinessId: my_buss.BusinessId } });
 
  //console.log(servicesList);
});




router.get("/mystaff", validateToken, async (req, res) => {
 
  const mystaff = await Business.findAll({ where: { UserId: req.user.id },include: [Staffs]});
 

  res.json(mystaff);
  console.log(mystaff);
});




router.delete("/:bussId", validateToken, async (req, res) => {
    const bussId = req.params.bussId;
    await Business.destroy({
      where: {
        id: bussId,
      },
    });
  
    res.json("BUSINESS DELETED SUCCESSFULLY");
  });


module.exports=router;

